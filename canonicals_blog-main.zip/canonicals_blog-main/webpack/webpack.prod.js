module.exports = {
	mode: 'production',
	devtool: false,
};
